from dotenv import load_dotenv
load_dotenv()

import os
from flask import Flask, render_template, request, redirect, url_for, g
from pymongo import MongoClient

# Initialize the Flask app
app = Flask(__name__)

# Get the MongoDB URI from the environment variable loaded from the .env file, falls back to localhost only if the variable is not found.
MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')

# --- Database Connection Management ---
def get_db():
    """
    Opens a new database connection if there is none yet for the
    current application context.
    """
    if 'db' not in g:
        # Use the MONGO_URI variable to connect
        client = MongoClient(MONGO_URI)
        g.db = client['survey_db']
    return g.db

@app.teardown_appcontext
def teardown_db(exception):
    """Closes the database again at the end of the request."""
    # This function is good practice but doesn't need changes for this fix.
    db_client = g.pop('db', None)


@app.route('/', methods=['GET', 'POST'])
def index():
    # Get the database connection for this request
    db = get_db()
    collection = db.users

    if request.method == 'POST':
        user_data = {
            'first_name': request.form.get('first_name'),
            'last_name': request.form.get('last_name'),
            'age': int(request.form.get('age')),
            'gender': request.form.get('gender'),
            'occupation': request.form.get('occupation'),
            'total_income': float(request.form.get('total_income'))
        }

        expense_categories = ['utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']
        for category in expense_categories:
            if request.form.get(f'expense_{category}'):
                amount = request.form.get(f'amount_{category}', 0)
                user_data[category] = float(amount) if amount else 0
            else:
                user_data[category] = 0

        collection.insert_one(user_data)
        
        return redirect(url_for('success'))

    return render_template('index.html')

@app.route('/success')
def success():
    return render_template('success.html')
